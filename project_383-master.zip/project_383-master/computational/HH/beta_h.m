function r = beta_h(V)
r = 1/(1 + exp(-(V + 35)/10));
end

