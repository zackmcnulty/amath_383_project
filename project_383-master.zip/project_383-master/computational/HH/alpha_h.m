function r = alpha_h(V)
r = 0.07*exp(-(V + 65)/20);
end

