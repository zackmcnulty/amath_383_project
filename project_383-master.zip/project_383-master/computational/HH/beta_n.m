function r = beta_n(V)
    
    r = 0.125*exp(-(V+65)/80);
end

