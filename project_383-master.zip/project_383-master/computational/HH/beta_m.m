function r = beta_m(V)
r =  4 *exp(-(V + 65)/18);
end

